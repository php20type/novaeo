<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Candidate;
use App\Models\RecruterJob;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class CandidateController extends Controller
{
    //
    public function index()
    {
        $candidates=Candidate::orderBy('id','desc')->with('job')->get();

        return view('admin.candidate.index',compact('candidates'));
    }
    public function show($id)
    {
        $candidate=Candidate::where('id',$id)->first();
        return view('admin.candidate.detail',compact('candidate'));
    }
    public function changeStatus($id,$status)
    {
        Candidate::where('id',$id)->update(['status'=>$status]);

        return redirect()->back();
    }
  
}
