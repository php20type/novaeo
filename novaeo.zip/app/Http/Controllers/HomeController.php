<?php

namespace App\Http\Controllers;

use App\Models\ContactEnquiry;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function contactEnquiry(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'mobile' =>'required',
            'email' =>'required',
            'message' =>'required',
        ]);
        ContactEnquiry::create(['name'=>$request->name,'email'=>$request->email,'mobile'=>$request->mobile,'message'=>$request->message]);

        return redirect()->back()->with('success','Contact Enquiry Sent Successfully !!!');
    }
}
