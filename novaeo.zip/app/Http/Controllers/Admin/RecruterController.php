<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RecruterJob;
use Illuminate\Support\Facades\Validator;
use Storage;

class RecruterController extends Controller
{
    //
    public function index(){
        $jobpost=RecruterJob::paginate(9);
        return view('admin.recruter.index',compact('jobpost'));
    }
    public function add(Request $request)
    {
        return view('admin.recruter.add');
    }
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'workplace_type' =>'required',
        ]);
        $filename='';
        if($request->has('fileUpload')){
            $filename =date('ymdhis').'_'. $request->fileUpload->getClientOriginalName();
            Storage::disk('uploads')->put($filename, file_get_contents($request->fileUpload->getRealPath()));
        }
        $job_id=RecruterJob::create(
            [ 'title'=>$request->title,
             'specification'=>$request->job_specification,
             'location'=>$request->location,
             'work_place'=>$request->workplace_type,
             'experience'=>$request->experience,
             'salary'=>$request->salary,
             'schedule'=>$request->schedule,
             'skill1'=>$request->skill1,
             'skill2'=>$request->skill2,
             'skill3'=>$request->skill3,
             'upload_file'=>$filename,
             'employment_type'=>$request->type_employee,
             'other_description'=>$request->other_description,
             'vacancy'=>$request->vacancy
             ]
            );
        return redirect('admin/recruter')->with('success','Job Post Added Succfully');
    }
    public function detail($id,Request $request)
    {
        $recruter=RecruterJob::whereId($id)->first();
        return view('admin.recruter.detail',compact('recruter'));
    }
    public function update(Request $request)
    {
        $job_id=RecruterJob::where('id',$request->id)->update(
            [ 
             'specification'=>$request->specification,
             'location'=>$request->location,
             'work_place'=>$request->workplace_type,
             'experience'=>$request->experience,
             'salary'=>$request->salary,
             'schedule'=>$request->schedule,
             'skill1'=>$request->skill1,
             'skill2'=>$request->skill2,
             'skill3'=>$request->skill3,
             'employment_type'=>$request->employment_type,
             ]
            );
        return redirect('admin/recruter/details/'.$request->id)->with('success','Job Post Updated Succfully');
    }
}
