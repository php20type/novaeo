<div class="col-lg-9">
    <div class="search-sec-main">
        <div class="search-bar">
            <input type="text" class="form-control" placeholder="Search" />
            <img class="search-icon" src="<?php echo e(asset('assets/admin/img/home/search-icon.svg')); ?>" />
            <a href="<?php echo e(route('admin.recruter.add')); ?>" type="button" value="">
                <img src="<?php echo e(asset('assets/admin/img/home/logout.svg')); ?>" /> &nbsp; Post Job
            </a>
        </div>
        <div class="user-con-block">
            <div class="user-notification-icon">
                <div class="notification-icon">
                    <img src="<?php echo e(asset('assets/admin/img/home/user-notification-icon.png')); ?>" />
                </div>
            </div>
            <?php if(!empty(Auth::guard('admin')->user())): ?>
            <div class="user-login-block">
                <div class="user-login-img">
                    <img src="<?php echo e(asset('assets/admin/img/home/user-img.jpg')); ?>" />
                </div>
                <div class="user-login-content-block">
                    <div class="user-login-content">
                        <a href="javascript:void(0)">
                            <h5><?php echo e(ucfirst(Auth::guard('admin')->user()->name)); ?></h5>
                            <p><?php echo e(Auth::guard('admin')->user()->email); ?></p>
                        </a>
                    </div>
                    <div class="user-login-arrow">
                        <svg width="9" height="6" viewBox="0 0 9 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 1L4.39474 5L8 1" stroke="#868686" stroke-linecap="round" />
                        </svg>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/admin/include/header.blade.php ENDPATH**/ ?>