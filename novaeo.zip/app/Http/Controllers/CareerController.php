<?php

namespace App\Http\Controllers;

use App\Models\RecruterJob;
use Illuminate\Http\Request;

class CareerController extends Controller
{
    //
    public function index()
    {
        $cities=RecruterJob::select('location')->groupBy('location')->get();
        return view('career',compact('cities'));
    }
}
