<?php $__env->startSection('content'); ?>
<!-- Banner Section Start -->
<section class="banner-sec-main">
    <div class="container-fluid">
        <div class="banner-inner">
            <div class="banner-slider-sec">
                <div class="banner-slide">
                    <div class="banner-con-area">
                        <img src="<?php echo e(asset('assets/front/img/banner-bg-img.png')); ?>" />
                        <div class="slider-img-con">
                            <h5>Lorem Ipsum is simply dummy text</h5>
                            <h2>Lorem Ipsum.</h2>
                        </div>
                    </div>
                </div>
                <div class="banner-slide">
                    <div class="banner-con-area">
                        <img src="<?php echo e(asset('assets/front/img/banner-bg-img.png')); ?>" />
                        <div class="slider-img-con">
                            <h5>Lorem Ipsum is simply dummy text</h5>
                            <h2>Lorem Ipsum.</span></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner Section End -->
<!-- About Section Start -->
<section class="about-sec-main">
    <div class="container">
        <div class="about-inner">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-img-block">
                        <img src="<?php echo e(asset('assets/front/img/about-img.png')); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-con-block">
                        <div class="custom-title">
                            <h2>About us</h2>
                        </div>
                        <div class="about-content">
                            <p>Novaeo is a team of eCommerce specialists that owns and manages several brands in the health and wellness market. Currently, Novaeo is operating 8 brands in the following markets: dietary supplements, tea, natural skincare, cosmetics, bulk health foods, spices, and sweeteners.</p>
                            <p>Novaeo was founded in August 2016 by Brandon Middleton. It is a team under LeiLuna formerly Wholesale Health Connection (WHC) which is the mother brand of Novaeo's awesome health-oriented brands.</p>
                        </div>
                        <div class="about-btn">
                            <a href="<?php echo e(route('about-us')); ?>">Read More <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1.32861L6 6.32861L1 11.3286" stroke="white" stroke-width="1.2" />
                                    <path d="M8 1.32861L13 6.32861L8 11.3286" stroke="white" stroke-width="1.2" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Section End -->
<!-- Who we are Section Start -->
<section class="who-sec-main">
    <div class="container">
        <div class="who-inner">
            <div class="row">
                <div class="col-md-6">
                    <div class="who-img-block">
                        <img src="<?php echo e(asset('assets/front/img/who-img-1.png')); ?>">
                        <div class="who-content">
                            <p>Our core competency is the ability to create and launch new product brands in a wide selection of product markets quickly and inexpensively. Our product formulation team is one of or perhaps the best in the USA.</p>
                            <p>As individuals, we are both inspired and inspiring. We are autonomous in our roles and growth while focusing on the collective. As a collective, we are warm but productive, we are jovial but focused. We are the creators of solutions and value.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="who-con-block who-con-block-2">
                        <div class="custom-title">
                            <h2>Who we are</h2>
                        </div>
                        <div class="who-content">
                            <p>We are extremely motivated and very team-oriented with a sort of teal business structure. We are adaptable and ever evolving, and the only thing bigger than our hearts is our vision. We are building an online community and business empire that will empower us to change the world. We value travel, social responsibility, personal development, team development, transparency, and freedom.</p>
                        </div>

                        <div class="who-img-block-2">
                            <img src="<?php echo e(asset('assets/front/img/who-img-2.png')); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Who we are Section End -->
<!-- Teal Business Structure Section Start -->
<section class="business-sec-main">
    <div class="container">
        <div class="business-inner">
            <div class="custom-title">
                <h2>Teal Business Structure</h2>
            </div>
            <div class="business-con-block">
                <div class="row">
                    <div class="col-md-4">
                        <div class="business-box">
                            <div class="business-box-block">
                                <div class="business-img">
                                    <img src="<?php echo e(asset('assets/front/img/Teal-img-1.png')); ?>">
                                </div>
                                <div class="business-content">
                                    <h3>Self- Management</h3>
                                    <p>Novaeo eliminates the hierarchy and embraces decentralization. Trust is placed in employees' individual and collective intelligencce. Everyone has a sense of responsibility and decision making is shared.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="business-box">
                            <div class="business-box-block">
                                <div class="business-img">
                                    <img src="<?php echo e(asset('assets/front/img/Teal-img-2.png')); ?>">
                                </div>
                                <div class="business-content">
                                    <h3>Wholeness</h3>
                                    <p>Employees in Novaeo are encouraged to develop not only as professionals, but as human beings. Maximizing individual’s potential by giving freedom to express one’s tureself.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="business-box">
                            <div class="business-box-block">
                                <div class="business-img">
                                    <img src="<?php echo e(asset('assets/front/img/Teal-img-3.png')); ?>">
                                </div>
                                <div class="business-content">
                                    <h3>Evolutionary Purpose</h3>
                                    <p>Instead of trying to predict the future, Novaeo goes with the flow, responding to the current purpose. There is no specific direction, the employees listen and understand each other and figure out the direction that they want to go together.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Teal Business Structure Section End -->
<!-- Get in touch with us Section Start -->
<section class="get-in-sec-main">
    <div class="container">
        <div class="get-in-inner">
            <div class="get-in-con-block">
                <div class="get-in-con-block-inner">
                    <div class="get-in-img-block">
                        <div class="get-in-img">
                            <img src="<?php echo e(asset('assets/front/img/get-int-touch-img.png')); ?>">
                        </div>
                        <div class="get-in-img-con-block">
                            <div class="custom-title">
                                <h2>Get in touch with us</h2>
                            </div>
                            <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success">
                                    <p><?php echo \Session::get('success'); ?></p>
                            </div>
                            <?php endif; ?>
                            <div class="get-in-form">
                                <form method="post" action="<?php echo e(route('contact-enquiry')); ?>">
                                    <div class="form-field">
                                        <input type="text" placeholder="Name" id="name" name="name" required>
                                    </div>
                                    <div class="form-field">
                                        <input type="text" placeholder="Phone Number" id="mobile" name="mobile" required>
                                    </div>
                                    <div class="form-field">
                                        <input type="email" placeholder="Email" id="email" name="email" required>
                                    </div>
                                    <div class="form-field">
                                        <textarea type="text" placeholder="Message" rows="5" id="message" name="message" required></textarea>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                    <div class="get-in-btn">
                                        <button type="submit">Contact Us <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1 1.32861L6 6.32861L1 11.3286" stroke="white" stroke-width="1.2" />
                                                <path d="M8 1.32861L13 6.32861L8 11.3286" stroke="white" stroke-width="1.2" />
                                            </svg>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="get-in-contact-block">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="get-in-contact-box">
                                <div class="get-in-contact-icon">
                                    <svg width="57" height="58" viewBox="0 0 57 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M47.5003 26.5259H52.2503C52.2503 14.3422 43.0519 5.15332 30.8516 5.15332V9.90332C40.4988 9.90332 47.5003 16.8929 47.5003 26.5259Z" fill="#009798" />
                                        <path d="M30.8757 19.4034C35.8703 19.4034 38.0007 21.5338 38.0007 26.5284H42.7507C42.7507 18.869 38.535 14.6534 30.8757 14.6534V19.4034ZM39.0029 32.3305C38.5466 31.9157 37.9469 31.6945 37.3305 31.7136C36.7141 31.7326 36.1292 31.9905 35.6993 32.4327L30.0159 38.2775C28.6479 38.0163 25.8977 37.1589 23.0667 34.335C20.2357 31.5016 19.3783 28.7443 19.1242 27.3858L24.9643 21.7C25.407 21.2705 25.6652 20.6855 25.6843 20.0689C25.7034 19.4523 25.4818 18.8525 25.0664 18.3964L16.2908 8.74677C15.8753 8.28925 15.2978 8.01172 14.6809 7.97314C14.0641 7.93456 13.4565 8.13796 12.9872 8.54015L7.83342 12.96C7.42281 13.3721 7.17773 13.9206 7.14467 14.5014C7.10904 15.0951 6.42979 29.1599 17.3358 40.0706C26.85 49.5825 38.7678 50.2784 42.05 50.2784C42.5298 50.2784 42.8243 50.2641 42.9027 50.2594C43.4834 50.2269 44.0316 49.9807 44.4417 49.5683L48.8592 44.4122C49.2617 43.9432 49.4655 43.3357 49.4273 42.7189C49.3892 42.1021 49.1121 41.5244 48.6549 41.1085L39.0029 32.3305Z" fill="#009798" />
                                    </svg>

                                </div>
                                <div class="get-in-contact-content">
                                    <a href="javascript:void(0)">(+123) 456-7890</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="get-in-contact-box">
                                <div class="get-in-contact-icon">
                                    <svg width="45" height="37" viewBox="0 0 45 37" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M45 10.7713V29.0908C45.0001 30.9586 44.2855 32.7557 43.0027 34.1133C41.72 35.471 39.9663 36.2863 38.1015 36.3921L37.6875 36.4033H7.3125C5.44469 36.4034 3.64764 35.6888 2.28998 34.4061C0.932325 33.1233 0.116997 31.3696 0.0112503 29.5048L0 29.0908V10.7713L21.717 22.1473C21.9586 22.2739 22.2273 22.34 22.5 22.34C22.7727 22.34 23.0414 22.2739 23.283 22.1473L45 10.7713ZM7.3125 0.40332H37.6875C39.5001 0.403102 41.2481 1.07606 42.5926 2.29167C43.9371 3.50728 44.7822 5.1789 44.964 6.98232L22.5 18.7498L0.0360001 6.98232C0.210428 5.25052 0.996862 3.63773 2.25394 2.43386C3.51101 1.22999 5.15628 0.513991 6.894 0.414571L7.3125 0.40332H37.6875H7.3125Z" fill="#009798" />
                                    </svg>


                                </div>
                                <div class="get-in-contact-content">
                                    <a href="javascript:void(0)">user@info.com</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="get-in-contact-box">
                                <div class="get-in-contact-icon">
                                    <svg width="31" height="40" viewBox="0 0 31 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 0.21582C11.3989 0.220658 7.46721 1.85195 4.5673 4.75186C1.6674 7.65176 0.0361046 11.5835 0.0312665 15.6846C0.0263546 19.036 1.12108 22.2965 3.14752 24.9658C3.14752 24.9658 3.56939 25.5213 3.6383 25.6014L15.5 39.5908L27.3674 25.5944C27.4292 25.5199 27.8525 24.9658 27.8525 24.9658L27.8539 24.9616C29.8793 22.2934 30.9736 19.0344 30.9688 15.6846C30.9639 11.5835 29.3326 7.65176 26.4327 4.75186C23.5328 1.85195 19.6011 0.220658 15.5 0.21582ZM15.5 21.3096C14.3875 21.3096 13.3 20.9797 12.3749 20.3616C11.4499 19.7435 10.7289 18.865 10.3032 17.8372C9.87745 16.8093 9.76606 15.6783 9.9831 14.5872C10.2001 13.496 10.7359 12.4938 11.5225 11.7071C12.3092 10.9204 13.3115 10.3847 14.4026 10.1677C15.4938 9.95061 16.6248 10.062 17.6526 10.4877C18.6804 10.9135 19.5589 11.6345 20.177 12.5595C20.7951 13.4845 21.125 14.5721 21.125 15.6846C21.1232 17.1758 20.5299 18.6055 19.4754 19.66C18.4209 20.7145 16.9913 21.3077 15.5 21.3096Z" fill="#009798" />
                                    </svg>


                                </div>
                                <div class="get-in-contact-content">
                                    <a href="javascript:void(0)">Brooklyn, New York,
                                        United States</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Get in touch with us Section End -->


<!-- Map Section Start -->
<section class="map-sec-main">
    <div class="container">
        <div class="map-inner">
            <div class="map-con-block">
                <div class="custom-title">
                    <h2>Where we are</h2>
                </div>
                <div class="map-img-block">
                    <img src="<?php echo e(asset('assets/front/img/map-img.png')); ?>">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Map Section End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/home.blade.php ENDPATH**/ ?>