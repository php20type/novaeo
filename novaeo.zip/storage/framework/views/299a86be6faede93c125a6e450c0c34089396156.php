<!DOCTYPE html>
<html lang="en" class="">

<head>
    <!-- Site Title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('admin/include/css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <section class="dashboard-main-section">
        <?php echo $__env->make('admin/include/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>

    </section>
    <?php echo $__env->make('admin/include/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>