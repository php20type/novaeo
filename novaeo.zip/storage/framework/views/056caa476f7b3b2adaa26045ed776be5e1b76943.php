

<?php $__env->startSection('title','Job Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="dash-content-area-sec">
    <div class="mobile-toogle">
        <div class="menu-icon" id="menu-Toggle">
            <a href="javascript:void(0)"><img src="<?php echo e(asset('assets/admin/img/home/menu.png')); ?>" /></a>
        </div>
        <div class="mobile-logo">
            <img src="<?php echo e(asset('assets/admin/img/logo/main.svg')); ?>" />
        </div>
    </div>
    <div class="container-fluid">
        <div class="dashboard-header-main-sec">
            <div class="row">
                <div class="col-lg-3">
                    <div class="left-title-fix">
                        <h4>Recruiters</h4>
                        <div class="logo-menu-block">
                            <ul>
                                <li>
                                    <a href="javascript:void(0)">
                                        <svg width="9" height="8" viewBox="0 0 9 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.81373 3.93446L4.72455 0.0876118C4.69511 0.0598391 4.66013 0.0378053 4.62164 0.0227718C4.58314 0.00773823 4.54187 0 4.50019 0C4.45851 0 4.41724 0.00773823 4.37874 0.0227718C4.34024 0.0378053 4.30526 0.0598391 4.27582 0.0876118L0.186639 3.93446C0.0675077 4.04661 0 4.19895 0 4.35783C0 4.68775 0.284922 4.95598 0.635367 4.95598H1.06623V7.70093C1.06623 7.86635 1.20819 8 1.38391 8H3.86482V5.90648H4.97671V8H7.61646C7.79218 8 7.93415 7.86635 7.93415 7.70093V4.95598H8.365C8.53377 4.95598 8.69559 4.89336 8.81472 4.78028C9.06192 4.54662 9.06192 4.16811 8.81373 3.93446Z" fill="#787878" />
                                        </svg>
                                        Home</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)">Recruiters</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('admin/include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
    <div class="recruiter-sec-main">
        <div class="recruiter-inner">
            <div class="row">
                <?php $__currentLoopData = $jobpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <a href="<?php echo e(route('admin.recruter.detail',$post->id)); ?>">
                        <div class="recruiter-box-block">
                            <div class="recruiter-box-img">
                                <img src="<?php echo e(asset('uploads/img').'/'.$post->upload_file); ?>" />
                            </div>
                            <div class="recruiter-detail-block">
                                <div class="recruiter-detail-content">
                                    <h5><?php echo e($post->title); ?></h5>
                                    <div class="recruiter-rating-list">
                                        <ul>
                                            <li>
                                                <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.8915 0L8.41429 4.49139H13.3421L9.35542 7.26722L10.8782 11.7586L6.8915 8.98278L2.90478 11.7586L4.42757 7.26722L0.440851 4.49139H5.3687L6.8915 0Z" fill="#FC8728" />
                                                </svg>
                                            </li>
                                            <li>
                                                <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.8915 0L8.41429 4.49139H13.3421L9.35542 7.26722L10.8782 11.7586L6.8915 8.98278L2.90478 11.7586L4.42757 7.26722L0.440851 4.49139H5.3687L6.8915 0Z" fill="#FC8728" />
                                                </svg>
                                            </li>
                                            <li>
                                                <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.8915 0L8.41429 4.49139H13.3421L9.35542 7.26722L10.8782 11.7586L6.8915 8.98278L2.90478 11.7586L4.42757 7.26722L0.440851 4.49139H5.3687L6.8915 0Z" fill="#FC8728" />
                                                </svg>
                                            </li>
                                            <li>
                                                <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.8915 0L8.41429 4.49139H13.3421L9.35542 7.26722L10.8782 11.7586L6.8915 8.98278L2.90478 11.7586L4.42757 7.26722L0.440851 4.49139H5.3687L6.8915 0Z" fill="#FC8728" />
                                                </svg>
                                            </li>
                                            <li>
                                                <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.8915 0L8.41429 4.49139H13.3421L9.35542 7.26722L10.8782 11.7586L6.8915 8.98278L2.90478 11.7586L4.42757 7.26722L0.440851 4.49139H5.3687L6.8915 0Z" fill="#FC8728" />
                                                </svg>
                                            </li>
                                        </ul>
                                        (66)
                                    </div>
                                    <h4><?php echo e($post->vacancy); ?> Job Open</h4>
                                    <p><?php echo e($post->location); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <section class="recruiter-pagination">
        <?php echo e($jobpost->links('admin.recruter.pagination')); ?>

        <!-- <nav aria-label="Page navigation example">
            <ul class="pagination mb-0">
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)" aria-label="Previous">
                        <svg width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 11L1 6L6 1" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)">1</a>
                </li>
                <li class="page-item">
                    <a class="page-link active" href="javascript:void(0)">2</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)">3</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)">...</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)">10</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)">11</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)" aria-label="Next">
                        <svg width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 11L6 6L1 1" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </a>
                </li>
            </ul>
        </nav> -->
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/admin/recruter/index.blade.php ENDPATH**/ ?>