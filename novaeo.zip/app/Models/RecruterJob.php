<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecruterJob extends Model
{
    use HasFactory;
    protected $table="recruter_job";

    protected $fillable = [
        'title',
        'specification',
        'location',
        'work_place',
        'experience',
        'salary',
        'schedule',
        'skill1',
        'skill2',
        'skill3',
        'employment_type',
        'other_description',
        'upload_file',
        'vacancy'
    ];
}
