<?php

namespace App\Http\Controllers;

use App\Models\Candidate;
use App\Models\ProfileViewLog;
use App\Models\RecruterJob;
use Illuminate\Http\Request;
use Auth;
use Storage;

class ApplyController extends Controller
{
    //
    public function index(Request $request)
    {
        $cities=RecruterJob::select('location')->groupBy('location')->get();

        $jobposts=RecruterJob::where('vacancy','>',0);
        if($request->job_title!=''){
            $jobposts->where('title','like','%'.$request->job_title.'%');
        }
        if($request->location!=''){
            $jobposts->where('location',$request->location);
        }
        $jobposts=$jobposts->get();
        $job_title=$request->job_title;
        $location=$request->location;
        $ipaddress=$request->getClientIp();
        ProfileViewLog::updateOrCreate(['ipaddress'=>$ipaddress],['ipaddress'=>$ipaddress]);
        return view('apply',compact('jobposts','cities','job_title','location'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'mobile' =>'required',
            'email' =>'required',
            'resume'=>'required'
        ]);

        $resumename='';
        $porfolioname='';
        $profilename='';
        if($request->has('resume')){
            $resumename =date('ymdhis').'_'. $request->resume->getClientOriginalName();
            Storage::disk('uploads_resume')->put($resumename, file_get_contents($request->resume->getRealPath()));
        }
        if($request->has('portfolio')){
            $porfolioname =date('ymdhis').'_'. $request->portfolio->getClientOriginalName();
            Storage::disk('uploads_portfolio')->put($porfolioname, file_get_contents($request->portfolio->getRealPath()));
        }
        if($request->has('profile')){
            $profilename =date('ymdhis').'_'. $request->profile->getClientOriginalName();
            Storage::disk('uploads_profile')->put($profilename, file_get_contents($request->profile->getRealPath()));
        }

        Candidate::create([
            'user_id'=>Auth::user()->id,
            'job_id'=>$request->job_id,
            'name'=>$request->name,
            'mobile'=>$request->mobile,
            'email'=>$request->email,
            'country'=>$request->country,
            'experience'=>$request->experience,
            'profile_link'=>$request->profile_link,
            'resume'=>$resumename,
            'portfolio'=>$porfolioname,
            'profile'=>$profilename,
        ]);
        
        return redirect()->back();
    }
}
